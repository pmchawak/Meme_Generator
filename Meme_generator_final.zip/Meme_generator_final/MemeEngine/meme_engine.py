"""Meme Engine module to make memes."""

import os
import time
from PIL import Image, ImageDraw, ImageFont
import random
import textwrap


class MemeEngine:
    """Meme Engine to refine and make meme image."""

    def __init__(self, results_dir):
        """Initialize results directory."""
        self.results_dir = self._ensure_dir(results_dir)
        if not self.results_dir: self.results_dir = '.'

    def _ensure_dir(self, path):
        """Create and allocate space for results directory."""
        try:
            os.mkdir(path, mode=0o700)
        except FileExistsError:
            return path
        except:
            raise

    def _resize_image(self, image, width):
        """Resize image for memes."""
        factor = 1
        if image.width > width:
            factor = round((width / image.width) * 100) / 100
        return image.resize((int(image.width * factor) - 1, int(image.height * factor) - 1))

    def _save_image(self, img, path):
        """Save image."""
        with open(path, 'wb') as fout:
            img.save(fout)

    def make_meme(self, img_path: str, body=None, author=None, width=500):
        """Make meme and wrap image and quote together."""
        if not body:  body = 'No Body Supplied'
        if not author: author = 'No Author Supplied'

        wrapper = textwrap.TextWrapper(width=30)
        out_path = self.results_dir + '/' + str(time.time()).replace('.', '-') + '.jpg'
        fnt = ImageFont.truetype('dejavu/DejaVuSansMono.ttf', 20)
        img = Image.open(img_path)
        word_list = wrapper.wrap(text=f"{body} - {author}")
        img = self._resize_image(img, width)
        context = ImageDraw.Draw(img)
        count = 20
        for word in word_list:
            context.text((50, count), word, font=fnt, fill="white")
            count = count + 20
        self._save_image(img, out_path)
        return out_path
