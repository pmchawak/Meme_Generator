"""Initialization function for Meme Engine module."""

from .meme_engine import MemeEngine
